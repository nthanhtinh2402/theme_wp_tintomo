<footer class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-left">
                    <div class="footer-left-logo">
                        <a href="">
                            <img src="<?php bloginfo('template_directory')?>./images/tintomo.png" alt="">
                        </a>
                    </div>
                    <div class="footer-left-web-info">
                        <p> 
                            Tạp chí điện tử Tri thức trực tuyến <br>
                            Cơ quan chủ quản: tintomo.com <br>
                            Giấy phép báo chí: số 75/GP-BTTTT do Bộ Thông tin và Truyền thông cấp ngày 26/02/2020<br>
                            Phụ trách điều hành: Nguyễn Nguyên<br>
                            Tổng thư ký Tòa soạn: tintomo.com<br>
                            © 2021 Toàn bộ bản quyền thuộc tintomo.com
                        </p>
                    </div>
                </div>
                <div class="footer-right">
                    
                    <p>
                        Tòa soạn: Tầng 4, 112 Đường số 4, Tân Tạo A, Q.Bình Tân <br>
                        Hotline: 0869.999.999 - Email: tintomo.com@gmail.com <br>
                    </p>
                </div>
            </div>
        </div>
    </footer>